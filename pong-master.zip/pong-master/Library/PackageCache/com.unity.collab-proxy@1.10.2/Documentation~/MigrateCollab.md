# Migration from Collaborate to Plastic SCM

Complete the steps to migrate Collaborate projects with the [Collaborate migration tool](https://www.plasticscm.com/plasticscm-cloud-edition/migrate-unity-projects/). You can invite your team members, set up your Plastic SCM workspace, and install Plastic SCM for Unity (beta).

 **Videos**

* [Migration Wizard](https://youtu.be/TKZuvPMprKg)
* [Plastic SCM Plugin Dev workflow](https://youtu.be/6_x3SLCiyWo)
* [Plastic SCM Plugin Gluon workflow](https://youtu.be/kfRu21cArGc)
